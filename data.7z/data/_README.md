This directory contains html, js, and css that supports basic configuration.

TODO:
1. update to use the minimized version as/if possible.
2. archive or delete the unused extra files.
3. Keep compiled version of code to less than 400k and then can use 192k SPIFFS and still get OTA
4. WTF 20171110 - why aren't updates getting through to Mac - suspect that need to wait for Cloudstation sync to complete?

Workaround on SPIFFS size is to do a bootstrap boot to a version that only has basic OTA and then OTA the larger image.

Original Source of code is based on: https://github.com/gmag11/FSBrowserNG
